package com.example.priceshare;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setSaveEnabled(false);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setSaveFormData(false);
        web.addJavascriptInterface(new Bridge(),"Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        // Intentionally do not save WebView state.
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        // Clear transient quotation data when the Activity is actually destroyed.
        try {
            if (web != null) {
                web.evaluateJavascript(
                    "try{document.querySelectorAll('input').forEach(function(e){e.value='';});" +
                    "document.querySelectorAll('select').forEach(function(e){e.selectedIndex=0;});}catch(e){}",
                    null
                );
                web.clearHistory();
                web.clearCache(true);
                web.clearFormData();
                web.destroy();
            }
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class Bridge {
        @JavascriptInterface public void share(){
            runOnUiThread(() -> { try { shareWebView(); } catch(Exception e) { } });
        }
    }

    private void shareWebView() throws Exception {
        web.evaluateJavascript("hideForShare()", v -> {
            web.postDelayed(() -> {
                Bitmap bm = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bm);
                web.draw(c);
                try {
                    Uri media = saveToMediaStore(bm);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/png");
                    i.putExtra(Intent.EXTRA_STREAM, media);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } catch (Exception noWhatsapp) {
                        i.setPackage(null);
                        startActivity(Intent.createChooser(i,"Share quotation image"));
                    }
                } catch(Exception ignored) { }
                web.evaluateJavascript("showAfterShare()", null);
            },250);
        });
    }

    private Uri saveToMediaStore(Bitmap bm) throws Exception {
        if(Build.VERSION.SDK_INT>=29){
            android.content.ContentValues v=new android.content.ContentValues();
            v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,"quotation_"+System.currentTimeMillis()+".png");
            v.put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png");
            v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PriceShare");
            Uri u=getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream o=getContentResolver().openOutputStream(u);
            bm.compress(Bitmap.CompressFormat.PNG,100,o);
            o.close();
            return u;
        }
        throw new Exception("Android version too old");
    }
}
