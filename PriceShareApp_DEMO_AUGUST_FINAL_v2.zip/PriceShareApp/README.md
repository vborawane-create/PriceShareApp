# Price Share Android App

This project converts the ARENA data from DEMO PRICE.xlsx into an offline Android quotation app. Select/search a model, enter customer details, and share the visible quotation as an image.

Build with Android Studio (AGP 8.6.1, compileSdk 35). The source data is embedded in `app/src/main/assets/data.json`.
