package com.example.priceshare;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); web.setBackgroundColor(Color.WHITE); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
    public class Bridge {
        @JavascriptInterface public void share(){ runOnUiThread(() -> { try { shareWebView(); } catch(Exception e){ } }); }
    }
    private void shareWebView() throws Exception {
        web.evaluateJavascript("hideForShare()", v -> {
            web.postDelayed(() -> {
                Bitmap bm=Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas c=new Canvas(bm); web.draw(c);
                try {
                    File dir=new File(getCacheDir(),"images"); dir.mkdirs();
                    File f=new File(dir,"quotation.png"); FileOutputStream out=new FileOutputStream(f); bm.compress(Bitmap.CompressFormat.PNG,100,out); out.close();
                    Uri uri=Uri.parse("content://com.example.priceshare.fileprovider/quotation.png");
                    // Use FileProvider-less fallback: share through a temporary content URI supplied by WebView's FileProvider is not available.
                    // Instead use ACTION_SEND with ClipData only on API 29+ via MediaStore.
                    Uri media=saveToMediaStore(bm);
                    Intent i=new Intent(Intent.ACTION_SEND); i.setType("image/png"); i.putExtra(Intent.EXTRA_STREAM,media); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(Intent.createChooser(i,"Share quotation image"));
                } catch(Exception e) { }
                web.evaluateJavascript("showAfterShare()", null);
            },250);
        });
    }
    private Uri saveToMediaStore(Bitmap bm) throws Exception {
        if(Build.VERSION.SDK_INT>=29){ android.content.ContentValues v=new android.content.ContentValues(); v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,"quotation_"+System.currentTimeMillis()+".png"); v.put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png"); v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PriceShare"); Uri u=getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v); OutputStream o=getContentResolver().openOutputStream(u); bm.compress(Bitmap.CompressFormat.PNG,100,o); o.close(); return u; }
        throw new Exception("Android version too old");
    }
}
